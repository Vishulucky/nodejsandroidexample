package com.example.nodejsexyoutube;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.nodejsexyoutube.model.StudentAdd;
import com.example.nodejsexyoutube.remote.APIService;
import com.example.nodejsexyoutube.remote.RetroClass;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddStudentActivity extends AppCompatActivity {


    private AppCompatEditText studentname , studentcourse;
    private Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_student);


        studentname=(AppCompatEditText)findViewById(R.id.name) ;
        studentcourse=(AppCompatEditText)findViewById(R.id.address) ;
        save= (Button)findViewById(R.id.addstudent);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                callData();

            }
        });





    }



      void callData()
      {
          APIService apiService = RetroClass.getAPIService();
          JsonObject gsonobject = new JsonObject();

          final JSONObject jsonObject=new JSONObject();
          try{

              jsonObject.put("name",""+studentname.getText().toString());
              jsonObject.put("course",""+studentcourse.getText().toString());
              JsonParser jsonParser= new JsonParser();
              gsonobject=(JsonObject)jsonParser.parse(jsonObject.toString());




          }
          catch (JSONException e)
          {

          }


          Call<StudentAdd> studentAddCall=apiService.addStudent(gsonobject);
          studentAddCall.enqueue(new Callback<StudentAdd>() {
              @Override
              public void onResponse(Call<StudentAdd> call, Response<StudentAdd> response) {


                  Log.d("result",""+response.body().getStatus());
              }

              @Override
              public void onFailure(Call<StudentAdd> call, Throwable t) {


              }
          });


      }


}

package com.example.nodejsexyoutube.remote;

public class APIURLS {


    public static final String BASE_URL="http://10.0.3.2:3000/";


}

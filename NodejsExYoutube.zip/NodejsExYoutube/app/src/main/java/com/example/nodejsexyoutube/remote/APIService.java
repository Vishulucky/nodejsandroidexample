
package com.example.nodejsexyoutube.remote;


import com.example.nodejsexyoutube.model.StudentAdd;
import com.example.nodejsexyoutube.model.StudentModel;
import com.google.gson.JsonObject;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface APIService {


    @GET("app/studentlist")
    Call<StudentModel> getStudentList();


    @POST("app/addStudent")
    Call<StudentAdd> addStudent(@Body JsonObject jsonObject);







}

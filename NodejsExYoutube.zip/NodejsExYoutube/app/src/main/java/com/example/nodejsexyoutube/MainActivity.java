package com.example.nodejsexyoutube;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.nodejsexyoutube.adapter.CustomAdapter;
import com.example.nodejsexyoutube.model.StudentModel;
import com.example.nodejsexyoutube.remote.APIService;
import com.example.nodejsexyoutube.remote.RetroClass;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private CustomAdapter customAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView =(RecyclerView)findViewById(R.id.recycleview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this,AddStudentActivity.class);
                startActivity(i);
            }
        });

        callData();

    }


    public void callData()
    {

        APIService apiService= RetroClass.getAPIService();
        Call<StudentModel>  studentModelCall=apiService.getStudentList();
        studentModelCall.enqueue(new Callback<StudentModel>() {
            @Override
            public void onResponse(Call<StudentModel> call, Response<StudentModel> response) {

                Log.d("response",""+response.body().getStatus());

                if(response.isSuccessful())
                {

                    customAdapter=new CustomAdapter(MainActivity.this,response.body().getResponse());
                    recyclerView.setAdapter(customAdapter);

                }


            }

            @Override
            public void onFailure(Call<StudentModel> call, Throwable t) {

                Log.d("responseerror",""+t.getMessage());
            }
        });




    }

}
